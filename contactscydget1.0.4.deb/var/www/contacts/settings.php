<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="height=device-height, width=device-width, minimum-scale=1.0, maximum-scale=2.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<script type='text/javascript' src='http://localhost/contacts/ajax.js'></script>
</head>
<?
$db=sqlite_open('contactscydget.sqlite', 0666, $sqliteerror);
$s=sqlite_query($db,"select * from setup where id='1'");
$cell=sqlite_fetch_array($s);
$theme=$cell[theme];
if ($theme=="dark"){
$mainfont="#fff";
$background='#262626';
}
else{
$mainfont="#000";
$background='#fff';
}
$ordering=$cell[ordering];
if ($theme=="light"){$lightvis="visible";$darkvis="hidden";}else{$lightvis="hidden";$darkvis="visible";}
if ($ordering=="name"){$namevis="visible";$surnamevis="hidden";}else{$namevis="hidden";$surnamevis="visible";}

?>
<div id=top style='width:320px;background:url(http://localhost/contacts/<? print $theme;?>/toolbr.png);height:55px;' align=left >
</div>
<div style='position:absolute;width:320px;top:0px;left:0px;text-align:center;font-family:Helvetica;font-size:20px;color:<? echo $mainfont;?>'>Contacts Cydget Settings</div>
<div align=right style='position:absolute;width:100px;top:30px;right:0px;text-align:right;font-family:Helvetica;font-size:20px;color:<? echo $mainfont;?>'><input type='button' onclick="ajax('http://localhost/contacts/index.php','main')" value=back></div>
<div align=center style='width:320px;background:#000'>
<br><div style='height:43px;border-bottom:1px solid #cccccc;background:#000;width:320px;font-family:helvetica;color:#fff;font-size:20px;font-weight:bold'>
Select Theme</div>
<div onclick="ajax('http://localhost/contacts/set.php?theme=light&a=x','');setTimeout('ajax(\'http://localhost/contacts/settings.php\',\'main\')',500)"  align=left style='position:relative;background:url(http://localhost/contacts/light/toolbr.png);border-bottom:1px solid #cccccc;height:40px;width:320px;font-family:helvetica;color:#262626;font-size:20px;font-weight:bold'>
Light<div id=light style='position:absolute;right:0px;bottom:0px;visibility:<? echo $lightvis; ?>'><img src=http://localhost/contacts/tick.png></div></div> 
<div onclick="ajax('http://localhost/contacts/set.php?theme=dark&a=x','');setTimeout('ajax(\'http://localhost/contacts/settings.php\',\'main\')',500)" align=left style='position:relative;background:url(http://localhost/contacts/dark/toolbr.png);border-bottom:1px solid #cccccc;height:40px;width:320px;font-family:helvetica;color:#fff;font-size:20px;font-weight:bold'>
Dark<div id=dark style='position:absolute;right:0px;bottom:0px;visibility:<? echo $darkvis; ?>'><img src=http://localhost/contacts/tick.png></div></div> 
<br>
<div style='height:43px;border-bottom:1px solid #cccccc;width:320px;font-family:helvetica;background:#000;color:#fff;font-size:20px;font-weight:bold'>
Select Order</div>

<div onclick="ajax('http://localhost/contacts/set.php?order=name&a=x','');setTimeout('ajax(\'http://localhost/contacts/settings.php\',\'main\')',500)"  align=left style='position:relative;background:<? echo $background;?>;border-bottom:1px solid #cccccc;height:40px;width:320px;font-family:helvetica;color:<? echo $mainfont;?>;font-size:20px;font-weight:bold'>
Name,Surname<div id=n style='position:absolute;right:0px;bottom:0px;visibility:<? echo $namevis; ?>'><img src=http://localhost/contacts/tick.png></div></div> 
<div onclick="ajax('http://localhost/contacts/set.php?order=surname&a=x','');setTimeout('ajax(\'http://localhost/contacts/settings.php\',\'main\')',500)" align=left style='position:relative;background:<? echo $background;?>;border-bottom:1px solid #cccccc;height:40px;width:320px;font-family:helvetica;color:<? echo $mainfont;?>;font-size:20px;font-weight:bold'>
Surname,Name<div id=s style='position:absolute;right:0px;bottom:0px;visibility:<? echo $surnamevis; ?>'><img src=http://localhost/contacts/tick.png></div></div> 
</div>
</div>
