<?
if($_GET[theme]!=""){
$db=sqlite_open('contactscydget.sqlite', 0666, $sqliteerror);
sqlite_query($db,"UPDATE setup set theme='$_GET[theme]' where id='1'");
}
if($_GET[order]!=""){
$db=sqlite_open('contactscydget.sqlite', 0666, $sqliteerror);
sqlite_query($db,"UPDATE setup set ordering='$_GET[order]' where id='1'");
}
?>
