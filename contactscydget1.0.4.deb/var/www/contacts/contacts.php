<?
$db=sqlite_open('contactscydget.sqlite', 0666, $sqliteerror);
$s=sqlite_query($db,"select * from setup where id='1'");
$cell=sqlite_fetch_array($s);
$theme=$cell[theme];
$order=$cell[ordering];
if ($theme=='dark'){
$listfont='#dadbdd';
$phonefont='#676767';
$callfont="#fff";
}
else{
$listfont='#474748';
$phonefont='#727272';
$callfont="#cc0000";
}
if ($order=="name"){
$ordering="ABPerson.first";
}
else{
$ordering="ABPerson.last";
}

$myFile = "/var/www/contacts/testFile.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
$std="
.output /var/www/contacts/alfa.txt \n
.mode csv \n";
if ($_POST[search]==""){
$std .="select ABPerson.first,ABPerson.last,ABMultiValue.value,ABMultiValue.property from ABPerson,ABMultiValue where ABMultiValue.record_id=ABPerson.ROWID order by $ordering asc;";
}
else{
$std .="select ABPerson.first,ABPerson.last,ABMultiValue.value,ABMultiValue.property from ABPerson,ABMultiValue where ABMultiValue.record_id=ABPerson.ROWID and ABPerson.first like '$_POST[search]%' or ABMultiValue.record_id=ABPerson.ROWID and ABPerson.last like '$_POST[search]%'order by $ordering asc;";
}

fwrite($fh, $std);
fclose($fh);
$command=shell_exec("sqlite3 /private/var/mobile/Library/AddressBook/AddressBook.sqlitedb < /var/www/contacts/testFile.txt ");
@unlink($myFile);
$handle = fopen("/var/www/contacts/alfa.txt", "r");
if (filesize("/var/www/contacts/alfa.txt")>0){
$contents = fread($handle, filesize("/var/www/contacts/alfa.txt"));
$clean="";
}
else{
$clean="<div align=center style='width:320px;font-family:helvetica;color:#c0c0c0;font-size:19px;height:50px;'><br>No results</div>";
}
fclose($handle);
$ab=explode(",3",$contents);
$a=0;
foreach($ab as $contact){
$a++;
$realcontact=explode(",",$contact);
$name=str_replace("\"","",$realcontact[0]);
$name=str_replace("'","",$name);
$surname=str_replace("\"","",$realcontact[1]);
$surname=str_replace("'"," ",$surname);
$phone=str_replace("\"","",$realcontact[2]);
if ($_POST[search]!=""){
$name=str_replace($_POST[search],"<span style='text-decoration:underline'>$_POST[search]</span>",$name);
$surname=str_replace($_POST[search],"<span style='text-decoration:underline'>$_POST[search]</span>",$surname);
}
if (strlen($name)=="1" and strlen($surname)=="0" or strlen($name)=="0" and strlen($surname)=="0" ){
}
else{
if ($order=="name"){
$show="$name <b>$surname</b>";
}
else{
$show="<b>$surname</b> $name";
}

print "<div id=caller$a onmousedown=\"try{clearTimeout(timex$a);clearTimeout(times$a);}catch(err){}if(document.getElementById('ghostdiv').innerHTML==this.id){call('$phone');};deselectall();document.getElementById('ghostdiv').innerHTML=this.id;document.getElementById('calling$a').style.visibility='visible';this.style.background='url(http://localhost/contacts/$theme/selected.png)';timex$a=setTimeout('clearout(\'caller$a\')',3000);times$a=setTimeout('document.getElementById(\'calling$a\').style.visibility=\'hidden\'',3000);\"  style='position:relative;width:320px;border-bottom:1px solid #000;height:43px;font-size:22px;font-family:helvetica;color:$listfont'>
$show<br><span style='color:$phonefont;font-size:12px;text-decoration:none;'>$phone</span><div id=calling$a style='position:absolute;right:0px;top:0px;color:#fff;font-weight:bold;visibility:hidden;font-size:12px'>Tap again to call</div></div>";
}
}
print $clean;
$c=-1;
print "<script type='text/javascript'>";
while ($c<=$a){
$c++;
print "thisvar$c=0;\n";
}
print "</script>";

?>
