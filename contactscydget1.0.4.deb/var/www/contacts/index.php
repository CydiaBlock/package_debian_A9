<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<script type='text/javascript'>
ajax('http://localhost/contacts/contacts.php','all');
var time;
var now = new Date();
var minutes = String(now.getMinutes());
var day = String(now.getDay());
var date = now.getDate();
var month = now.getMonth();
var year = now.getFullYear();
var weekhuman= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
var monthhuman= ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
if (minutes.length == 1)
minutes = '0' + minutes
time = now.getHours() + ':' + minutes;
datex =  weekhuman[day] + " " + monthhuman[month] + " " + date+ " "+year;
document.getElementById('time').innerHTML="<b>"+time+"</b><br>"+datex;
</script>
<?
$db=sqlite_open('contactscydget.sqlite', 0666, $sqliteerror);
$s=sqlite_query($db,"select * from setup where id='1'");
$cell=sqlite_fetch_array($s);
$theme=$cell[theme];
if ($theme=="dark"){
$mainfont="#fff";
$background='#262626';
}
else{
$mainfont="#000";
$background='#fff';
}
$usrname=shell_exec('uname -a');
$upos=strpos($usrname,'iPhone');
$username=substr($usrname,0,$upos);
$username=str_replace("Darwin","",$username);
$username=str_replace("-"," ",$username);
$tot=shell_exec("sqlite3 /private/var/mobile/Library/AddressBook/AddressBook.sqlitedb 'select count(distinct ABPerson.ROWID) from ABPerson where 1'");
?>
 <meta name="viewport" content="height=device-height, width=device-width, minimum-scale=1.0, maximum-scale=2.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
</head>
<div id=ghostdiv style='visibility:hidden;height:0px;width:0px;'></div>

<div id=top style='width:320px;background:url(http://localhost/contacts/<? print $theme;?>/toolbr.png);height:55px;' align=left >
</div>
<div align=center style='position:absolute;width:320px;top:0px;left:0px;text-align:center;font-family:Helvetica;font-size:12px;color:<? print $mainfont;?>'>
<div id=time></div>
</div>
<div style='position:absolute;top:30px;right:0px;height:30px;'>
<input type=button style='font-family:helvetica;font-size:12px;' onclick="ajax('http://localhost/contacts/settings.php','main')" value='Settings'>
</div>
<div style='position:absolute;top:28px;left:5px;height:30px;'>
<input type=text style='padding-left:19px;width:185px;height:18px;background-color:#fff;background:url(http://localhost/contacts/srch.png);background-repeat:no-repeat;color:#c0c0c0;' value='Search' onmousedown="if(this.value=='Search'){this.value='';this.style.color='#262626'}" onkeyup="setTimeout('ajax(\'http://localhost/contacts/contacts.php\',\'all\',\'search='+this.value+'&sf=l\',\'POST\')',200)">
</div>
<div id=all style='background:<? echo $background;?>;'></div>
