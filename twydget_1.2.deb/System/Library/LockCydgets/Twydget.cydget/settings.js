///////////////////////////////////////
// Twydget 1.2
// www.twydget.com
///////////////////////////////////////
//
//  ANY CHANGES REQUIRE A RESPRING
//
//  Enter your username and password
//  in between the double quotes "";
//
///////////////////////////////////////

var username = "";
var password = "";

///////////////////////////////////////
//
//  To display your normal lock screen
//  background on Twydget, simply add
//  YES in between the double quotes "";
//
///////////////////////////////////////

var LockBackground = "NO";

///////////////////////////////////////
//
//  To use a custom theme / stylesheet,
//  place a new stylesheet.css in the
//  theme folder, and specify the file
//  name below
//
///////////////////////////////////////

var DefaultTheme = "default.css";