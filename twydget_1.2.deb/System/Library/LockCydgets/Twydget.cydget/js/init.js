///////////////////////////////////////
// Twydget 1.2
// www.twydget.com
///////////////////////////////////////

function settings() {

	// user/pass has been configured in settings.js, hide login
	if (username!=null && username!="") {
		document.getElementById('loginTip').innerHTML = '<div class="profile"><a href="http://m.twitter.com/' + username + '">Profile</a> &nbsp; <a href="configuration.html">Settings</a> &nbsp; <a href="configuration.html">Sign Out</a></div><input id="TextUser" type="hidden" value="' + username + '" /><input id="TextPassword" type="hidden" value="' + password + '" />';
		
	} else if (localStorage.user != null && localStorage.pass != null) {
		// user/pass has been stored in localStorage, hide login
		document.getElementById('loginTip').innerHTML = '<div class="profile"><a href="http://m.twitter.com/' + localStorage.user + '">Profile</a> &nbsp; <a href="configuration.html">Settings</a> &nbsp; <a href="load.html" onclick="signout(); return true" target="_parent">Sign out</a></div><input id="TextUser" type="hidden" value="' + localStorage.user + '" /><input id="TextPassword" type="hidden" value="' + localStorage.pass + '" />';
		document.getElementById('footer').innerHTML = '<br><font style="font-size:8pt;"><b>Tip:</b> The username and password will clear every respring. <br>You can permanently set the username, password, <br>and other settings via SSH/FTP by editing /System/Library/LockCydgets/Twydget.cydget/settings.js</font><br><br>';		

	} else {	
		// user/pass was not detected, display login
		document.getElementById('loginLeft').innerHTML = '<div id="loginUser"><input id="TextUser" type="text" name="TextUser" placeholder="Username" onkeyup="return storeuser()" /></div>';
		document.getElementById('loginRight').innerHTML = '<div id="loginPassword"><input id="TextPassword" type="password" name="TextUser" placeholder="Password" onkeyup="return storepass()" style="float:left;" /><form onsubmit="signin(); return false" action="load.html" name="twydget" method="post" target="_parent" style="float:left;"><input id="TextGo" type="submit" value="Go" style="font-size:10pt;width:45px;padding:0px;margin-top:5px;margin-left:5px;"></form></div>';
		document.getElementById('loginTip').innerHTML = '<br><b>Tip:</b> You can set the username and password via SSH /System/Library/LockCydgets/Twydget.cydget/settings.js';
	}
	
	// user the default theme or a different one
	if (DefaultTheme!="default.css") {
		document.getElementById('defaultTheme').innerHTML = '<link href="theme/' + defaultTheme + '" rel="stylesheet" type="text/css" />';
	} 

	// restore users input after device goes to sleep
	if (localStorage.tweet != null) {
		document.getElementById('TextArea1').value = localStorage.tweet;
		document.getElementById('Textlength').value = 140 - localStorage.tweetlength;
	}
	
	if (localStorage.user != null) {
		document.getElementById('TextUser').value = localStorage.user;	
	}

	if (localStorage.pass != null) {
		document.getElementById('TextPassword').value = localStorage.pass;
	}

}



var makeSignedRequest = function(ck,cks,encodedurl) {	  

	var accessor = { consumerSecret: cks, tokenSecret: ""}; 	 
	var message = { action: encodedurl, method: "GET", parameters: [["oauth_version","1.0"],["oauth_consumer_key",ck]]};

	OAuth.setTimestampAndNonce(message);
	OAuth.SignatureMethod.sign(message, accessor);

	var parameterMap = OAuth.getParameterMap(message);
	var baseStr = OAuth.decodeForm(OAuth.SignatureMethod.getBaseString(message));		
	var theSig = "";

	if (parameterMap.parameters) {
		for (var item in parameterMap.parameters) {
			for (var subitem in parameterMap.parameters[item]) {
				if (parameterMap.parameters[item][subitem] == "oauth_signature") {
					theSig = parameterMap.parameters[item][1];		      
					break;			    
				}
			}
		}
	}

	var paramList = baseStr[2][0].split("&");
	paramList.push("oauth_signature="+theSig);
	paramList.sort(function(a,b) {
		if (a[0] < b[0]) return -1;
		if (a[0] > b[0]) return 1;
		if (a[1] < b[1]) return  -1;
		if (a[1] > b[1]) return 1;
		return 0;
	});

	var locString = "";
	for (var x in paramList) {
		locString += paramList[x] + "&";		
	}

	var finalStr = baseStr[1][0] + "?" + locString.slice(0,locString.length - 1);
	return finalStr;

};
var xurl = "";
var signedURL = ""; 

var loadJSON = function(url) {
	var headID = document.getElementsByTagName("head")[0];	       
	var newScript = document.createElement('script');
		newScript.type = 'text/javascript';
		newScript.src = url;
	headID.appendChild(newScript);
}

//function myCallback (response) { response = eval(response); }

var myCallback = function(response) {

	var errorCode = response.query.diagnostics.url[2]['http-status-code'];
	var errorMessage = response.query.diagnostics.url[2]['http-status-message'];
	
	if (errorCode == "401") {
		var ButtonPost = document.getElementById('ButtonPost');
		ButtonPost.disabled = false;
		document.getElementById('loginTip').innerHTML = "<div style='float:left;color:red;font-weight:bold;font-size:8pt;'><br>Username or Password is incorrect.</div>";
		localStorage.removeItem('user');
		localStorage.removeItem('pass');
		return false;
	
	} else if (errorCode =="403") {
		document.getElementById('loginTip').innerHTML = "<div style='float:left;color:white;font-weight:bold;font-size:8pt;'><br>Logging in.</div>";
		top.location = "load.html";
	} else {
		var TextArea1 = document.getElementById('TextArea1');
		var ButtonPost = document.getElementById('ButtonPost');
		var TextUser = document.getElementById('TextUser');
		var TextPassword = document.getElementById('TextPassword');
	
	    TextArea1.value = "";
	    ButtonPost.disabled = false;
	    
		document.getElementById('main').style.display = 'none';
	
	    if (username!=null && username!="") {
		document.getElementById('mainFooter').innerHTML = '<div class="notes"><div class="notesTweet">Tweet posted successfully, '+ username +'</div><br><br><a href="http://m.twitter.com/' + TextUser.value + '">View your Twitter Profile</a><br><br><a href="twydget.html">Post another Tweet</a><br><br></div>';
	    } else {
		document.getElementById('mainFooter').innerHTML = '<div class="notes"><div class="notesTweet">Tweet posted successfully, '+ TextUser.value +'</div><br><br><a href="http://m.twitter.com/' + TextUser.value + '">View your Twitter Profile</a><br><br><a href="twydget.html">Post another Tweet</a><br><br><small>You can permanently set the username, password, and other settings via SSH/FTP by editing <sup>/System/Library/LockCydgets/Twydget.cydget/settings.js</sup></small><br><br></div>';
	    }
	    	
	}

}

function storeuser() {
	var TextUser = document.getElementById('TextUser');
	localStorage.setItem('user', TextUser.value);
}

function storepass() {
	var TextPassword = document.getElementById('TextPassword');
	localStorage.setItem('pass', TextPassword.value);
}

function signin() {
	var TextUser = document.getElementById('TextUser');
	localStorage.setItem('user', TextUser.value);
	var TextPassword = document.getElementById('TextPassword');
	localStorage.setItem('pass', TextPassword.value);
	
    var xTweet = "";
	
	if (TextUser.value!=="" && TextUser.value!=="") {
		    xTweet = xTweet.replace(/@/g, "%40");
		    xurl = "https://query.yahooapis.com/v1/public/yql?q=USE%20%22http%3A%2F%2Fwww.yqlblog.net%2Fsamples%2Ftwitter.status.xml%22%3B%20INSERT%20INTO%20twitter.status%20(status%2C%20username%2C%20password)%20VALUES%20(%22" + xTweet + "%22%2C%20%22" + TextUser.value + "%22%2C%20%22" + TextPassword.value + "%22)&format=json&callback=myCallback";
		    signedURL = makeSignedRequest("dj0yJmk9Rm1MUU9iWmdNZ2FjJmQ9WVdrOVZWWk9Wa3h5TldFbWNHbzlNVEk0TXpNMk1EYzFPQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1kMg--", "570e2ef3db460b114e6a0a987709a0f6a90b5ec0", xurl);
		
		    loadJSON(signedURL);
		    
	} else {
		document.getElementById('loginTip').innerHTML = '<div style="float:left;color:red;font-weight:bold;font-size:8pt;"><br>Username and Password Required.</div>';
	}
//	return true;
}

function signout() {
	localStorage.removeItem('user');
	localStorage.removeItem('pass');
}

function twitlength() {
	var Textlength = document.getElementById('Textlength');
	var TextArea1 = document.getElementById('TextArea1');
	localStorage.setItem('tweet', TextArea1.value);
	localStorage.setItem('tweetlength', TextArea1.value.length);

    Textlength.value = 140 - TextArea1.value.length 
}


function ButtonPost_onclick() {
	var Textlength = document.getElementById('Textlength');
	var TextArea1 = document.getElementById('TextArea1');
	var TextUser = document.getElementById('TextUser');
	var TextPassword = document.getElementById('TextPassword');
	var ButtonPost = document.getElementById('ButtonPost');
    var xTweet = escape(TextArea1.value);
	
	if (TextUser.value!=="" && TextUser.value!=="") {
		if (xTweet!=="") {		
		    ButtonPost.disabled = true;
		    xTweet = xTweet.replace(/@/g, "%40");
		    xurl = "https://query.yahooapis.com/v1/public/yql?q=USE%20%22http%3A%2F%2Fwww.yqlblog.net%2Fsamples%2Ftwitter.status.xml%22%3B%20INSERT%20INTO%20twitter.status%20(status%2C%20username%2C%20password)%20VALUES%20(%22" + xTweet + "%22%2C%20%22" + TextUser.value + "%22%2C%20%22" + TextPassword.value + "%22)&format=json&callback=myCallback";
		    signedURL = makeSignedRequest("dj0yJmk9Rm1MUU9iWmdNZ2FjJmQ9WVdrOVZWWk9Wa3h5TldFbWNHbzlNVEk0TXpNMk1EYzFPQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1kMg--", "570e2ef3db460b114e6a0a987709a0f6a90b5ec0", xurl);
		
		    loadJSON(signedURL);
		    
			localStorage.removeItem('tweet');
			localStorage.removeItem('tweetlength');
					    
		} else {
			document.getElementById('loginTip').innerHTML = '<div style="float:left;color:red;font-weight:bold;font-size:8pt;"><br>Forgetting something?</div>';
		}
	} else {
		document.getElementById('loginTip').innerHTML = '<div style="float:left;color:red;font-weight:bold;font-size:8pt;"><br>Username and Password Required.</div>';
	}
	return false;
} 



