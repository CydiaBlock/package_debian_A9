export EDITOR=vi
