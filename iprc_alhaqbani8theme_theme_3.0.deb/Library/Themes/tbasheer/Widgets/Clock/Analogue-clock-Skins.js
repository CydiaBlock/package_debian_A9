CoolClock.config.skins = {

/*
You only need to edit hourHand, minuteHand and secondDecoration to change colours
*/

	WhiteHands: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "none", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "none", alpha: 0 },
		hourHand: { lineWidth: 3, startAt: -19, endAt: 40, color: "white", alpha: 1 },
		minuteHand: { lineWidth: 3, startAt: -19, endAt: 55, color: "white", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 55, color: "red", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	BlackHands: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "black", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "DimGrey", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "DimGrey", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#green", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour1: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "WhiteSmoke", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour2: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour3: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour4: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour5: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},

	Colour6: {
		outerBorder: { lineWidth: 60, radius:30, color: "black", alpha: 0.0 },
		smallIndicator: { lineWidth: 2, startAt: 60, endAt: 65, color: "grey", alpha: 0 },
		largeIndicator: { lineWidth: 7, startAt: 59, endAt: 67, color: "grey", alpha: 0 },
		hourHand: { lineWidth: 8, startAt: -1, endAt: 40, color: "WhiteSmoke", alpha: 1 },
		minuteHand: { lineWidth: 7, startAt: -1, endAt: 50, color: "WhiteSmoke", alpha: 1 },
		secondHand: { lineWidth: 3, startAt: 22, endAt: 68, color: "#FF0000", alpha: 0 },
		secondDecoration: { lineWidth: 4, startAt: 0, endAt: 62, fillColor: "#FF3936", color: "red", alpha: 0.6 }
	},
};
