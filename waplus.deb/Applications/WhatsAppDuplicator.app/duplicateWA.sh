#!/bin/sh

tempLoc=$(find /var/mobile/Applications/ -name "WhatsApp.app")


if [ ! -z "$tempLoc" ]; then
	AppCount=$(echo "$tempLoc" | wc -l)
	if [ $AppCount -gt 1 ]; then
	    echo ""
	else
	    mkdir /tmp/WA2
	    mkdir /tmp/WA2/Payload
	    cp -rf $tempLoc /tmp/WA2/Payload
	    plutil -key CFBundleIdentifier -value net.whatsapp.WhatsAppFoo /tmp/WA2/Payload/WhatsApp.app/Info.plist
	    plutil -key CFBundleDisplayName -value WhatsApp+ /tmp/WA2/Payload/WhatsApp.app/Info.plist
	    cd /tmp/WA2 && zip -r dup.ipa *
	    ipainstaller -f /tmp/WA2/dup.ipa
        touch /var/mobile/.whatsappDup
	fi
fi

