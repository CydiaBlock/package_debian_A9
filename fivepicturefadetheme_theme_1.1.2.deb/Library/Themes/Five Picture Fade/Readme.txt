***Five Picture Fade Readme***
You can change the fading images by copying them to the /var/stash/Themes/Five Picture Fade/Images/ folder. Make sure you change the image names to Image1.png; Image2.png etc.

Then respring when you're done.
Don't know how to respring? Go to Winterboard, then deactivate and activate the Five Picture Fade option. Or you can go to SBSettings > Respring.

If you're still stuck, see this YouTube video: http://www.youtube.com/watch?v=smeviC62tsU

If you like the Five Picture Fade theme, make sure you rate and review!

Thanks for downloading,
mmfgamer5 (author of Five Picture Fade)



Advertisment links:
iMakeThemes - http://ijailbreak.weebly.com/imakethemes.html
iPhonehelps - http://iphonehelps1.co.cc
Miniclip Forums - http://forums.miniclip.com