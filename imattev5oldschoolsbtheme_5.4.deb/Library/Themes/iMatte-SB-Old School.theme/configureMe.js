/* *************************************** */
/* The following scripts will allow you to finetune */

/* *************************************** */

/* **************** CLOCK **************** */
//Toggles twelve and twenty-four hour time.
// false = 12h time format
// true = 24h time format

var twentyFourHourTime = true;


/* *************************************** */
/* ************* LANGUAGE **************** */
//Choose Languages :
// English = EN
// French = FR
// Italian = IT
// Spanish = ES
// German = DE
// Russian = RU

var language = 'EN';


/* *************************************** */
/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - If you don't know your WOEID, go here: http://sigizmund.info/woeidinfo/ and enter your city name to find out.

*/

/* Step 2 - Then enter your city code here */
var locale = "3547" 

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = false

/* Minutes between updates */
var updateInterval = 10


/* ****************************************************** */
