<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<br><br><br><br>
<CENTER>
<script language="JavaScript">
function gotourl()
{
window.location.href = document.Testform.url.value;
return false;
}
</script>
<small><small>
Respring if you have bugs
<br>NOTE:SpringBoard can crash sometimes!
<br>Respring it and everaything works again!
</small></small>
<form name="Testform" onSubmit="return gotourl()">
URL:
<input size=15% name="url" value="http://">
<input type=submit value="Go">
</form>
<img src="file:///System/Library/LockCydgets/LockScreen-Browser.cydget/tap.jpg" />
</CENTER>
</body>
</html>

