#!/bin/sh
# Check that xDrivesrv.conf exists.
[ -f /var/mobile/Library/xDrive/xDrivesrv.conf ] || echo "/var/mobile/Library/xDrive/xDrivesrv.conf not found" || exit 0

case "$1" in
start)
    /Applications/xDrive.app/xDrivesrv -D -f /var/run/xDrivesrv.pid
    ;;

stop)
    killall xDrivesrv -15
    rm /var/run/xDrivesrv.pid
    rm -rf /var/run/xDrivesrv
    ;;

restart)
    $0 stop
    $0 start
    ;;

*)
    echo "Use: $0 {start|stop|restart}"
    exit 1
    esac
