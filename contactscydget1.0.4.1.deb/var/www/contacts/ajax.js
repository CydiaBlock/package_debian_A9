function ajax(url, layer, sendData, methodx, callfunction) {
var that=this;                                                    
var stillupdating = false;                                             
this.callbacknow = function() {}     
this.updatenow = function(PassedData,method) {                                
if (stillupdating==true) { return false; }                          
stillupdating=true;                                                 
var AJAX = null;                                               
if (window.XMLHttpRequest) {                                   
AJAX=new XMLHttpRequest();                                  
} else {                                                       
AJAX=new ActiveXObject("Microsoft.XMLHTTP");                
}                                                              
if (AJAX==null) {                                              
alert("Your browser doesn't support AJAX.");                
return false                                                
} else {         AJAX.onreadystatechange = function() {                      
if (AJAX.readyState==4 || AJAX.readyState=="complete") { 
if (LayerID!="" && LayerID!=undefined){

var response = AJAX.responseText;
response = response.split("<!")[0];
LayerID.innerHTML=AJAX.responseText;    
var thescripts = response.split(/\<\/?script[^\<]*\>/i)[1];
try{eval(thescripts)}catch(err){};
}
delete AJAX;                                          
stillupdating=false;                                       
that.callbacknow();                                      
}                                                        
}                                                           
var timestamp = new Date();                                 
if (/post/i.test(method)){
var uri=urlCall+'?'+'timestamp='+(timestamp*1);    
AJAX.open('POST', uri, true);                             
AJAX.setRequestHeader("Content-type", "application/x-www-form-urlencoded");        
AJAX.setRequestHeader("Content-Length", PassedData.length);        
AJAX.send(PassedData);                                               
}
else{
if (PassedData==""){
}
var uri=urlCall+'?'+PassedData+'&timestamp='+(timestamp*1); 
AJAX.open('GET', uri, true);                                
AJAX.send(null);   
}
return true;                                                
}                                                              
}         
if (layer!=undefined){
var LayerID = document.getElementById(layer);                   
}
else{
var LayerID="";
}
var urlCall = url;    
var methodtouse = methodx;
var callbacknow = callfunction;
var PassedData= sendData || "";
this.updatenow(PassedData,methodtouse);
}                        


